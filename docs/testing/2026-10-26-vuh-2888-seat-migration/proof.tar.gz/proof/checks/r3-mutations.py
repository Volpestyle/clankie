"""Recheck changed updater/doctor guards; preserve earlier unchanged guard receipts."""
import hashlib, json, os, re, subprocess
from pathlib import Path
root = Path(__file__).resolve().parents[2]
previous = root / '.local/vuh2888-proof/r2-mutations'
out = root / '.local/vuh2888-proof/r3-mutations'
out.mkdir(mode=0o700)
rows = json.loads((previous/'results.json').read_text())
selected = [row for row in rows if row['code'].startswith('U') or row['code']=='D1']
for row in selected:
    if row['code']=='U1':
        row['before']='      enforceSeats &&\n      !(await operatorSeatsReady('
        row['after']='      false &&\n      !(await operatorSeatsReady('
selected.append(dict(code='D2',name='D2 pending enforcing update loses headline',source='apps/tui/src/command/doctor.ts',before=' || report.pendingEnforcingUpdate',after='',command=['node_modules/.bin/vitest','run','apps/tui/test/doctor-fleet-link.integration.test.ts']))
env = dict(os.environ)
home = out/'home'
home.mkdir(mode=0o700)
env.update(HOME=str(home),NODE_ENV='test',VITEST='true',VITEST_MAX_WORKERS='1')
for key in ['XDG_CONFIG_HOME','XDG_STATE_HOME','XDG_DATA_HOME','XDG_CACHE_HOME','XDG_RUNTIME_DIR','CLAUDE_CONFIG_DIR','CODEX_HOME']:
    path=home/key; path.mkdir(mode=0o700); env[key]=str(path)
for row in selected:
    path=root/row['source']; original=path.read_bytes(); source=original.decode()
    assert source.count(row['before'])==1, row['code']
    try:
        path.write_text(source.replace(row['before'],row['after']))
        result=subprocess.run(row['command'],cwd=root,env=env,capture_output=True,text=True,timeout=180)
        log=result.stdout+result.stderr
        (out/(row['code']+'.log')).write_text(log)
        match=re.search(r'^\s*Tests\s+(.+)',log,re.M)
        row.update(exit=result.returncode,tests=match.group(1) if match else None,
                   killed=result.returncode!=0 and re.search(r'^\s*Tests\s+\d+ failed',log,re.M) is not None,
                   originalSha256=hashlib.sha256(original).hexdigest())
        print(json.dumps(row),flush=True)
    finally:
        path.write_bytes(original)
        assert path.read_bytes()==original
    rows=[item for item in rows if item['code']!=row['code']]+[row]
    (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
    assert row['killed'],row['code']
assert len(rows)==28 and all(row['killed'] for row in rows)
for row in rows:
    assert hashlib.sha256((root/row['source']).read_bytes()).hexdigest()==row['originalSha256'],row['code']
print('All 28 guards killed on matching source bytes; exact restoration verified.',flush=True)
