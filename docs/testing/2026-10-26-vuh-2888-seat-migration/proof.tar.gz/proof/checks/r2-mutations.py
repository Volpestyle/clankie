"""Owned-tree mutation run. Invoke only under heavy, with no concurrent source checks/edits."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parents[2]
out = root / '.local/vuh2888-proof/r2-mutations'
out.mkdir(exist_ok=False)
reviewer = Path('/HOME/dev/clankie-wt/review-standing-20261027-r8/.local/scratch-logs')
mutations = []
for name in ['mut2888.py', 'mut2888u.py']:
    tree = ast.parse((reviewer / name).read_text())
    for statement in tree.body:
        if isinstance(statement, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'muts' for target in statement.targets):
            # Resolve only the reviewer's literal constants; never execute its driver.
            constants = {}
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant):
                    for target in node.targets:
                        if isinstance(target, ast.Name): constants[target.id] = node.value.value
            for entry in statement.value.elts:
                mutations.append(tuple(constants[item.id] if isinstance(item, ast.Name) else ast.literal_eval(item) for item in entry.elts))

core = 'apps/clankie/test/'
tui = 'apps/tui/test/'
mutations.extend([
    ('C1 unlinked fallback removed', 'packages/fleet-resources/src/native.py', 'image, words = arguments(pid)', 'raise RuntimeError("Unlinked fallback removed")'),
    ('D1 observe diagnostics take headline', 'apps/tui/src/command/doctor.ts', 'binding.mode !== "observe"', 'true'),
])
def selection(code):
    if code == 'C1': return [core+'operator-seat-inventory.integration.test.ts']
    if code == 'D1': return [tui+'doctor-fleet-link.integration.test.ts']
    if code in ['B1', 'B2', 'B3']:
        return [core+'operator-seat-binding-native.integration.test.ts', core+'operator-seat-bindings.test.ts']
    if code == 'B4' or code.startswith('M') or code.startswith('R'):
        return [core+'operator-seat-migration.integration.test.ts']
    if code in ['H1', 'H2']: return [core+'operator-seat-hold.test.ts']
    if code == 'H3': return [core+'conversation-driver.test.ts', '-t', 'executionHeld']
    if code == 'H4': return [core+'captain-conversation-driver.test.ts', '-t', 'default-head migration']
    if code in ['U3', 'U5']: return [tui+'runtime-update.test.ts', '-t', 'checkout update refuses']
    if code == 'U4': return [tui+'runtime-update.test.ts', '-t', 'checkout enforcing activation']
    return [tui+'release-update.integration.test.ts', '-t', 'enforcing|complete:false']

scratch = out / 'home'
scratch.mkdir(mode=0o700)
env = dict(os.environ)
# Isolate only the admitted child, leaving the outer governor unchanged.
env.update(HOME=str(scratch), NODE_ENV='test', VITEST='true', VITEST_MAX_WORKERS='1')
for key in ['XDG_CONFIG_HOME', 'XDG_STATE_HOME', 'XDG_DATA_HOME', 'XDG_CACHE_HOME', 'XDG_RUNTIME_DIR', 'CLAUDE_CONFIG_DIR', 'CODEX_HOME']:
    path = scratch / key
    path.mkdir(mode=0o700)
    env[key] = str(path)
results = []
for name, relative, before, after in mutations:
    code = name.split()[0]
    path = root / relative
    original = path.read_bytes()
    source = original.decode()
    if source.count(before) != 1:
        raise RuntimeError(f'{name}: pattern count {source.count(before)}; re-anchor explicitly')
    args = ['node_modules/.bin/vitest', 'run', '--config', 'vitest.config.ts', *selection(code)]
    try:
        path.write_text(source.replace(before, after))
        result = subprocess.run(args, cwd=root, env=env, capture_output=True, text=True, timeout=180)
        log = result.stdout + result.stderr
        (out / f'{code}.log').write_text(log)
        summary = re.search(r'^\s*Tests\s+(.+)', log, re.M)
        failed = re.search(r'^\s*Tests\s+(\d+) failed', log, re.M)
        row = dict(code=code, name=name, source=relative, before=before, after=after,
                   command=args, exit=result.returncode, tests=summary.group(1) if summary else None,
                   killed=result.returncode != 0 and failed is not None,
                   originalSha256=hashlib.sha256(original).hexdigest())
        results.append(row)
        print(json.dumps(row), flush=True)
    finally:
        path.write_bytes(original)
        if path.read_bytes() != original: raise RuntimeError('Restoration failed')
    (out / 'results.json').write_text(json.dumps(results, indent=2)+'\n')
    if not row['killed']: raise RuntimeError(f'{code} survived or failed without a discovered failing test')
print(f'All {len(results)} mutations killed; exact source bytes restored.', flush=True)
