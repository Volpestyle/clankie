import { defineConfig } from 'vitest/config';
import { appendFileSync } from 'node:fs';
import base from '../../vitest.config.ts';
const kind=process.env.PROOF_MUTATION;
const mutation={name:'vuh2888-enforcing-boundary-mutation',enforce:'pre' as const,transform(code:string,id:string){
  if(!id.split('?')[0].endsWith('/apps/clankie/src/operator-seat-bindings.ts'))return;
  const needle=kind==='nonce'?'if (!timingSafeEqual(claimed, Buffer.from(entry.nonceHash, "hex")))':'if (observedHarness.ppid !== controller.pid)';
  if(!code.includes(needle))throw Error('Mutation target changed');
  appendFileSync(new URL(`./${kind}-mutation-applied.log`,import.meta.url),id+'\n');
  return code.replace(needle,kind==='nonce'?'if (false && !timingSafeEqual(claimed, Buffer.from(entry.nonceHash, "hex")))':'if (false && observedHarness.ppid !== controller.pid)');
 }};
export default defineConfig({...base,plugins:[mutation],test:{...base.test,
 projects:base.test!.projects!.map(project=>({...project,plugins:[mutation]})),
}});
