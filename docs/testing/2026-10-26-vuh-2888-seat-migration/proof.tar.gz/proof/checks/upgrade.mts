import { execFileSync, spawn, type ChildProcess } from 'node:child_process';
import { createWriteStream, existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync, copyFileSync, chmodSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { randomUUID, createHash } from 'node:crypto';
import { parseEnv } from 'node:util';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { executeRuntimeUpdate } from '../../apps/tui/bin/runtime-update.ts';
import { createPinnedWorktree, installPinnedLinks } from '../../apps/tui/bin/pinned-runtime.ts';

const source = resolve(import.meta.dirname, '../..');
const root = join(import.meta.dirname, process.env.PROOF_RUN ?? 'run-1');
if (existsSync(root)) throw Error('Proof root already exists; preserve the original attempt');
mkdirSync(root,{recursive:true,mode:0o700});
const setupLog=createWriteStream(join(root,'driver.log'));
const record=(label:string,data:unknown)=>{writeFileSync(join(root,`${label}.json`),JSON.stringify(data,null,2)+'\n');console.log(label);};
const run=(command:string,args:readonly string[],cwd=source,env=process.env)=>execFileSync(command,[...args],{cwd,env,encoding:'utf8',timeout:30*60_000,maxBuffer:8*1024*1024}).trim();
const checkout=join(root,'checkout');
run('git',['clone','--shared','--no-checkout',source,checkout]);
const base=run('git',['rev-parse','HEAD']);
run('git',['checkout','-b','proof',base],checkout);
const changed=[...run('git',['diff','--name-only']).split('\n'),...run('git',['ls-files','--others','--exclude-standard']).split('\n')].filter(Boolean);
if(process.env.PROOF_REQUIRE_CLEAN==='1')assert.equal(changed.length,0,'Upgrade proof requires committed candidate bytes');
for(const path of changed){mkdirSync(dirname(join(checkout,path)),{recursive:true});copyFileSync(join(source,path),join(checkout,path));}
const gitEnv={...process.env,GIT_AUTHOR_NAME:'Volpestyle',GIT_AUTHOR_EMAIL:'volpestyle@gmail.com',GIT_COMMITTER_NAME:'Volpestyle',GIT_COMMITTER_EMAIL:'volpestyle@gmail.com'};
if(changed.length){
 run('git',['add','--',...changed],checkout,gitEnv);
 run('git',['commit','-m','Proof fixture: preparation artifact'],checkout,gitEnv);
}
const prep=run('git',['rev-parse','HEAD'],checkout);
writeFileSync(join(checkout,'apps/clankie/operator-seat-policy.json'),'{"schemaVersion":1,"mode":"enforce"}\n');
run('git',['add','apps/clankie/operator-seat-policy.json'],checkout,gitEnv);
run('git',['commit','-m','Proof fixture: enforcing artifact'],checkout,gitEnv);
const enforcing=run('git',['rev-parse','HEAD'],checkout);
run('git',['checkout',prep],checkout);
record('source-bindings',{sourceHead:base,preparationCommit:prep,enforcingCommit:enforcing,
 preparationIsCommittedCandidate:prep===base,
 preparationTree:run('git',['rev-parse',`${prep}^{tree}`],checkout),
 enforcingDiff:run('git',['diff','--binary',prep,enforcing],checkout)});
run(process.execPath,['scripts/scratch-stack.mjs',join(root,'stack')]);
const preset=parseEnv(readFileSync(join(root,'stack/stack.env'),'utf8'));
const scratchHome=preset.HOME!;
const runtime=join(scratchHome,'.clankie/pinned');
const output=join(root,'native');mkdirSync(output,{recursive:true});
const childEnv:NodeJS.ProcessEnv={PATH:process.env.PATH,LANG:'en_US.UTF-8',...preset,NODE_ENV:'test',VITEST:'true',
 XDG_STATE_HOME:join(root,'xdg-state'),XDG_DATA_HOME:join(root,'xdg-data'),XDG_CACHE_HOME:join(root,'xdg-cache'),XDG_RUNTIME_DIR:join(root,'xdg-runtime'),
 CLAUDE_CONFIG_DIR:join(scratchHome,'.claude'),CODEX_HOME:join(scratchHome,'.codex'),TMPDIR:join(root,'tmp'),
 CLANKIE_RUNTIME_DIR:runtime,CLANKIE_TEST_FLEET_RESOURCES_DIRECTORY:join(root,'fixture-resources'),
 CLANKIE_TEST_OPERATOR_PID_FILE:join(scratchHome,'owned-pids.json'),PROOF_SOURCE:runtime,PROOF_OUTPUT:output,
 pnpm_config_verify_deps_before_run:'false'};
for(const name of ['HOME','XDG_CONFIG_HOME','XDG_STATE_HOME','XDG_DATA_HOME','XDG_CACHE_HOME','XDG_RUNTIME_DIR','CLAUDE_CONFIG_DIR','CODEX_HOME','TMPDIR']){
 const path=childEnv[name]!;assert(path.startsWith(root+'/'));mkdirSync(path,{recursive:true,mode:0o700});}
writeFileSync(childEnv.CLANKIE_TEST_OPERATOR_PID_FILE!,JSON.stringify([process.pid]));
record('isolation',Object.fromEntries(Object.entries(childEnv).filter(([key])=>!key.includes('TOKEN'))));
const bin=join(scratchHome,'.local/bin');mkdirSync(bin,{recursive:true});
copyFileSync(join(import.meta.dirname,'native-harness.mjs'),join(bin,'claude'));chmodSync(join(bin,'claude'),0o755);
childEnv.PATH=`${bin}:${process.env.PATH}`;
const copyDependencies=(destination:string)=>{
 for(const path of ['node_modules',...['apps','packages','integrations'].flatMap(group=>readdirSync(join(source,group)).map(name=>`${group}/${name}/node_modules`))]){
  if(existsSync(join(source,path))&&!existsSync(join(destination,path))){mkdirSync(dirname(join(destination,path)),{recursive:true});run('/bin/cp',[process.platform==='darwin'?'-cR':'-a',join(source,path),join(destination,path)]);}
 }
};
copyDependencies(checkout);
const old='a9e39f3c91976b6395c0c1cee3821895e091a388';
const command=(cmd:string,args:readonly string[],cwd:string)=>run(cmd,args,cwd,childEnv);
createPinnedWorktree(checkout,runtime,old,command);copyDependencies(runtime);
const baselineUpdater=await import(pathToFileURL(join(runtime,'apps/tui/bin/runtime-update.ts')).href);
await installPinnedLinks(runtime,scratchHome);
let service:ChildProcess|undefined;
const natives:ChildProcess[]=[];
const exited=(child:ChildProcess)=>child.exitCode!==null||child.signalCode!==null;
const wait=async <T>(fn:()=>T|Promise<T>,accept:(value:T)=>boolean,ms=30_000):Promise<T>=>{
 const deadline=Date.now()+ms;let last:unknown;for(;;){try{const value=await fn();if(accept(value))return value;last=value;}catch(error){last=error;}if(Date.now()>deadline)throw Error(`Proof wait failed: ${String(last)}`);await new Promise(done=>setTimeout(done,100));}
};
const host=preset.CLANKIE_CONTROL_PLANE_URL!;
const api=async(path:string,body?:unknown)=>{
 const response=await fetch(host+path,{method:body===undefined?'GET':'POST',headers:{connection:'close',authorization:`Bearer ${preset.CLANKIE_OPERATOR_TOKEN}`,'content-type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.timeout(30_000)});
 return {status:response.status,body:await response.json()};
};
const boot=async()=>{
 const log=createWriteStream(join(root,`service-${Date.now()}.log`));
 service=spawn(process.execPath,['--import',join(runtime,'scripts/dependency-types.mjs'),join(runtime,'apps/clankie/src/index.ts')],{cwd:runtime,env:childEnv,stdio:['ignore','pipe','pipe']});
 service.stdout!.pipe(log);service.stderr!.pipe(log);
 return wait(async()=>{if(service!.exitCode!==null)throw Error(`service exited ${service!.exitCode}`);return (await api('/health')).body;},value=>value.ok===true,60_000);
};
const stopService=async()=>{
 if(!service||service.exitCode!==null)return;
 const owned=service;owned.kill('SIGTERM');
 await wait(()=>owned.exitCode,code=>code!==null,20_000);service=undefined;
};
const cli=(...args:string[])=>JSON.parse(command(process.execPath,[join(runtime,'apps/tui/bin/clankie.ts'),...args],runtime));
const updatePids=()=>{
 const rows=readdirSync(output).filter(path=>path.endsWith('.ready.json')).map(path=>JSON.parse(readFileSync(join(output,path),'utf8')));
 writeFileSync(childEnv.CLANKIE_TEST_OPERATOR_PID_FILE!,JSON.stringify([process.pid,...natives.filter(child=>!exited(child)).map(child=>child.pid!),...rows.flatMap(row=>[row.pid,row.mcpPid]).filter(Number.isSafeInteger)]));
};
const launch=async(args:string[],resumedSession?:string)=>{
 if(resumedSession){try{run('/bin/mv',[join(output,`${resumedSession}.ready.json`),join(output,`${resumedSession}.previous.json`)]);}catch{}}
 const log=createWriteStream(join(root,`launcher-${Date.now()}.log`));
 const child=spawn(process.execPath,[join(runtime,'apps/tui/bin/clankie.ts'),'claude',...args],{cwd:root,env:childEnv,stdio:['ignore','pipe','pipe']});
 natives.push(child);child.stdout!.pipe(log);child.stderr!.pipe(log);
 const row=await wait(()=>readdirSync(output).filter(path=>path.endsWith('.ready.json')).map(path=>JSON.parse(readFileSync(join(output,path),'utf8'))).find(row=>row.launcher===child.pid),Boolean,45_000);
 updatePids();return {child,row};
};
const control=async(row:any,body:unknown)=>{const response=await fetch(`http://127.0.0.1:${row.port}`,{method:'POST',body:JSON.stringify(body),signal:AbortSignal.timeout(30_000)});return response.json();};
const endNative=async(entry:any)=>{process.kill(entry.row.pid,'SIGTERM');await wait(()=>entry.child.exitCode,(code)=>code!==null,20_000);updatePids();};
const transact=async(target:string)=>{
 const id=randomUUID(),directory=join(scratchHome,'.clankie/updates',id);mkdirSync(directory,{recursive:true,mode:0o700});
 const health=(await api('/health')).body;
 const engine=target===prep?baselineUpdater.executeRuntimeUpdate:executeRuntimeUpdate;
 const result=await engine({id,ref:target,checkout,runtime,home:scratchHome,directory,oldCommit:run('git',['rev-parse','HEAD'],runtime),newCommit:target,oldInstanceId:health.runtime.instanceId},{
  run:command,retryDelaysMs:[],operatorSeatsReady:async()=>{const state=await api('/v1/captain/seat-bindings');return state.status===200&&state.body.inventory?.complete===true&&state.body.inventory?.ready===true;},
  services:async(_runtime,action)=>{if(action==='down'){await stopService();return {ok:true,services:[{id:'clankie',ok:true,state:'stopped'}]};}
    const booted=await boot();return {ok:true,services:[{id:'clankie',ok:true,state:'running',pid:service!.pid!}],runtime:booted.runtime};},
 });
 record(`update-${id}`,result);return result;
};
try {
 const oldHealth=await boot();record('baseline-health',oldHealth);
 const first=await launch(['--conversation','global-default']);
 const second=await launch(['--new']);
 record('baseline-native',[first.row,second.row]);
 const marker=`one-effect-${randomUUID()}`;
 await control(first.row,{call:{name:'message_seat',arguments:{seat:second.row.conversationId,message:marker}},dropReply:true}).catch(()=>undefined);
 await wait(()=>control(second.row,{}),result=>result.events.some((event:any)=>event.params.content.includes(marker)));
 const lostResult=JSON.parse(readFileSync(join(output,`${first.row.sessionId}.lost-result.json`),'utf8'));
 const receipt=lostResult._meta?.['clankie/seat-call']?.id;
 assert.equal(typeof receipt,'string',JSON.stringify(lostResult));
 record('original-receipt',{receipt,marker,transportReply:'deliberately dropped after original dispatch'});
 const prepResult=await transact(prep);assert.equal(prepResult.phase,'healthy');
 await wait(()=>control(first.row,{tools:true}),result=>result.tools?.some((tool:any)=>tool.name==='message_seat'));
 const legacyDoctor=await api('/v1/captain/seat-bindings');record('legacy-doctor',legacyDoctor);
 assert.equal(legacyDoctor.body.mode,'observe');assert.equal(legacyDoctor.body.inventory.seats.length,2);assert(legacyDoctor.body.inventory.seats.every((seat:any)=>!seat.bound));
 const afterMarker=`prep-call-${randomUUID()}`;
 const afterCall=await control(first.row,{call:{name:'message_seat',arguments:{seat:second.row.conversationId,message:afterMarker}}});
 assert.notEqual(afterCall.isError,true);assert.equal(afterCall.structuredContent?.deliveryStage,'delivered');
 await wait(()=>control(second.row,{}),result=>result.events.some((event:any)=>event.params.content.includes(afterMarker)));
 record('legacy-call-after-upgrade',{marker:afterMarker,result:afterCall});
 const refused=await transact(enforcing);assert.equal(refused.phase,'refused');assert.equal(refused.reason,'operator-seats-unready');
 record('legacy-tools-survive',await control(first.row,{tools:true}));
 const reconciled=await control(first.row,{call:{name:'reconcile_seat_call',arguments:{deliveryId:receipt}}});
 record('original-reconciled',reconciled);assert.equal(reconciled._meta?.['clankie/seat-call']?.id,receipt);
 for(const entry of [first,second]) {
  const id=randomUUID();const prepared=await api('/v1/captain/seat-migrations',{action:'prepare',id,conversationId:entry.row.conversationId});record(`migration-${id}-prepare`,prepared);assert.equal(prepared.status,200);
  const held=await control(entry.row,{call:{name:'message_seat',arguments:{seat:entry===first?second.row.conversationId:first.row.conversationId,message:'must-not-dispatch-while-held'}}});
  record(`migration-${id}-new-call-refused`,held);assert.equal(held.isError,true);
  const living=await api('/v1/captain/seat-migrations',{action:'claim',id,sessionId:entry.row.sessionId,conversationId:entry.row.conversationId,cwd:entry.row.cwd,profile:entry.row.profile});assert.equal(living.status,409);record(`migration-${id}-living-refusal`,living);
  await endNative(entry);
  const next=await launch(['--resume',entry.row.sessionId,'--conversation',entry.row.conversationId,'--migration',id],entry.row.sessionId);
  assert.equal(next.row.sessionId,entry.row.sessionId);assert.equal(next.row.cwd,entry.row.cwd);assert.equal(next.row.profile,entry.row.profile);assert.notEqual(next.row.pid,entry.row.pid);
  const completed=await wait(()=>api('/v1/captain/seat-migrations',{action:'complete',id}),value=>value.status===200);record(`migration-${id}-complete`,completed);
  Object.assign(entry,next);
 }
 const ready=await api('/v1/captain/seat-bindings');record('ready-doctor',ready);assert.equal(ready.body.inventory.ready,true);
 const enforced=await transact(enforcing);assert.equal(enforced.phase,'healthy');
 const finalDoctor=await api('/v1/captain/seat-bindings');record('enforcing-doctor',finalDoctor);assert.equal(finalDoctor.body.mode,'enforce');assert.equal(finalDoctor.body.inventory.ready,true);
 const effects=readFileSync(join(output,`${second.row.sessionId}.events.jsonl`),'utf8').trim().split('\n').map(line=>JSON.parse(line)).filter((event:any)=>event.params.content.includes(marker));assert.equal(effects.length,1);
 const afterEffects=readFileSync(join(output,`${second.row.sessionId}.events.jsonl`),'utf8').trim().split('\n').map(line=>JSON.parse(line)).filter((event:any)=>event.params.content.includes(afterMarker));assert.equal(afterEffects.length,1);
 record('continuity',{old,prep,enforcing,sessions:[first.row,second.row],originalReceipt:receipt,effectCount:effects.length,postUpgradeEffectCount:afterEffects.length,noModelCalls:true});
 // A killed launcher cannot make its surviving operator harness disappear
 // from the enforcement precondition's native census.
 first.child.kill('SIGKILL');await wait(()=>exited(first.child),Boolean);updatePids();
 const orphan=await wait(()=>api('/v1/captain/seat-bindings'),value=>value.body.inventory?.seats?.some((seat:any)=>seat.nativeSessionOnly&&seat.conversationId===first.row.conversationId&&!seat.bound));
 record('orphan-launcher-refused',orphan);assert.equal(orphan.body.inventory.ready,false);
 process.kill(first.row.pid,'SIGTERM');
} finally {
 for(const child of [...natives].reverse()) if(!exited(child)){try{const rows=readdirSync(output).filter(path=>path.endsWith('.ready.json')).map(path=>JSON.parse(readFileSync(join(output,path),'utf8')));const row=rows.find(row=>row.launcher===child.pid);if(row)process.kill(row.pid,'SIGTERM');else child.kill('SIGTERM');await wait(()=>exited(child),Boolean,10_000);}catch{child.kill('SIGKILL');}}
 await stopService();setupLog.end();
}
