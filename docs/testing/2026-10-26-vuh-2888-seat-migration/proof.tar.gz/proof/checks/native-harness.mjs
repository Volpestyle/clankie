#!/usr/bin/env node
// Deterministic native dependency for the owned upgrade proof. No model.
import { createRequire } from 'node:module';
import { mkdirSync, readFileSync, writeFileSync, appendFileSync } from 'node:fs';
import { join } from 'node:path';
import { createServer } from 'node:http';
import { execFileSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
if (process.argv.includes('--version')) { console.log('2.1.310 (deterministic proof dependency)'); process.exit(0); }
const root = process.env.PROOF_SOURCE;
const require = createRequire(join(root, 'apps/clankie/package.json'));
const { Client } = await import(require.resolve('@modelcontextprotocol/sdk/client/index.js'));
const { StdioClientTransport } = await import(require.resolve('@modelcontextprotocol/sdk/client/stdio.js'));
const { z } = await import(require.resolve('zod'));
const args = process.argv.slice(2);
const at = args.includes('--resume') ? args.indexOf('--resume') : args.indexOf('--session-id');
const sessionId = args[at + 1];
if (!sessionId || sessionId !== process.env.CLANKIE_SEAT_SESSION_ID) throw Error('session mismatch');
if (process.env.CLANKIE_BRIDGE_NONCE || process.env.CLANKIE_BRIDGE_NONCE_FILE) throw Error('nonce leaked to harness');
const cwd = process.cwd();
const projects = join(process.env.CLAUDE_CONFIG_DIR, 'projects', cwd.replace(/[^A-Za-z0-9]/gu, '-'));
mkdirSync(projects, { recursive: true });
const transcript = join(projects, `${sessionId}.jsonl`);
try { readFileSync(transcript); } catch { writeFileSync(transcript, JSON.stringify({ type:'user', uuid:randomUUID(), sessionId, cwd, timestamp:new Date().toISOString(), message:{role:'user',content:'Owned upgrade context; do not execute anything.'} })+'\n'); }
const config = JSON.parse(readFileSync(args[args.indexOf('--mcp-config')+1], 'utf8')).mcpServers.clankie;
const expand = value => value.replace(/\$\{([^}:]+)(?::-([^}]*))?\}/gu, (_all,key,fallback)=>process.env[key]??fallback??'');
const transport = new StdioClientTransport({ command:config.command, args:config.args.map(expand),
  cwd, env:{...process.env,...config.env}, stderr:'pipe' });
const client = new Client({name:'owned-upgrade-native-dependency',version:'1'}, {capabilities:{experimental:{'claude/channel':{}}}});
const events = [];
client.setNotificationHandler(z.object({method:z.literal('notifications/claude/channel'),params:z.object({content:z.string(),meta:z.record(z.string(),z.string()).optional()})}), async event => {
  events.push(event);
  appendFileSync(join(process.env.PROOF_OUTPUT, `${sessionId}.events.jsonl`), JSON.stringify(event)+'\n');
});
transport.stderr?.on('data',chunk=>appendFileSync(join(process.env.PROOF_OUTPUT, `${sessionId}.bridge.log`),chunk));
await client.connect(transport);
const tools = await client.listTools();
execFileSync('clankie',['seat-sync'],{env:process.env,input:JSON.stringify({hook_event_name:'SessionStart',session_id:sessionId,transcript_path:transcript}),timeout:30000});
const server = createServer(async (incoming,outgoing)=>{
  try {
    let body='';for await (const chunk of incoming) body+=chunk;
    const request=JSON.parse(body||'{}');
    const result=request.call?await client.callTool(request.call):request.tools?await client.listTools():{events};
    if (request.dropReply) {
      // Preserve the original native result's ID for independent read-only
      // reconciliation. The bridge allocates its own ID; callers cannot pick it.
      writeFileSync(join(process.env.PROOF_OUTPUT, `${sessionId}.lost-result.json`), JSON.stringify(result));
      outgoing.destroy(); return;
    }
    outgoing.end(JSON.stringify(result));
  } catch(error) { outgoing.statusCode=500;outgoing.end(JSON.stringify({error:String(error)})); }
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
writeFileSync(join(process.env.PROOF_OUTPUT,`${sessionId}.ready.json`), JSON.stringify({pid:process.pid,launcher:process.ppid,mcpPid:transport.pid,sessionId,conversationId:process.env.CLANKIE_CONVERSATION_ID,cwd,profile:process.env.CLAUDE_CONFIG_DIR,port:server.address().port,tools:tools.tools.map(tool=>tool.name),resumed:args.includes('--resume')}));
process.on('SIGTERM',async()=>{server.closeAllConnections();server.close();await client.close();process.exit(0);});
