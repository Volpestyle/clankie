import hashlib
import json
import os
from pathlib import Path
import shutil
import tarfile
import subprocess

repo = Path(__file__).resolve().parents[2]
proof = repo / '.local/vuh2888-proof'
stage = proof / 'sanitized-r3'
if stage.exists():
    raise RuntimeError('Preserve the previous sanitized archive attempt')
stage.mkdir(mode=0o700)
final = proof / 'run-10'
binding = json.loads((final / 'source-bindings.json').read_text())
assert binding['preparationIsCommittedCandidate']
assert binding['preparationCommit'] == binding['sourceHead']
subprocess.run(['git', 'merge-base', '--is-ancestor', binding['sourceHead'], 'HEAD'], cwd=repo, check=True)
continuity = json.loads((final / 'continuity.json').read_text())
orphan = json.loads((final / 'orphan-launcher-refused.json').read_text())
assert continuity['effectCount'] == continuity['postUpgradeEffectCount'] == 1
assert orphan['body']['inventory']['complete'] and not orphan['body']['inventory']['ready']
assert any(row.get('nativeSessionOnly') and not row['bound'] for row in orphan['body']['inventory']['seats'])
secrets = []
for run in proof.glob('run-*'):
    preset = run / 'stack/stack.env'
    if preset.is_file():
        for line in preset.read_text().splitlines():
            if 'TOKEN=' in line:
                value = line.split('=', 1)[1].strip().strip('"').strip("'")
                if len(value) > 8:
                    secrets.append(value)

def sanitize(text):
    for secret in secrets:
        text = text.replace(secret, '<SCRATCH_TOKEN_REDACTED>')
    text = text.replace(str(repo), '/SCRATCH/vuh-2888').replace('/HOME', '/HOME')
    lines = text.splitlines()
    # Governor wait diagnostics name unrelated real holders; omit those lines.
    return '\n'.join(line for line in lines if not line.startswith(('  server: ', '  full: ', '  light: ', 'clankie heavy: '))) + '\n'

def retain(path, relative):
    destination = stage / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    text = path.read_text()
    if path.name == 'isolation.json':
        value = json.loads(text)
        value['PATH'] = '<inherited toolchain PATH; scratch bin prepended before native launch>'
        text = json.dumps(value, indent=2)
    destination.write_text(sanitize(text))

for path in proof.iterdir():
    if path.is_file() and path.suffix in ('.log', '.mts', '.mjs', '.ts'):
        retain(path, Path('checks') / path.name)
for path in (proof / 'r2-mutations').iterdir():
    if path.is_file() and path.suffix in ('.json', '.log'):
        retain(path, Path('checks/r2-mutations') / path.name)
retain(proof / 'package-evidence.py', Path('checks/package-evidence.py'))
retain(proof / 'r2-mutations.py', Path('checks/r2-mutations.py'))
retain(proof / 'r2-strict-doctor-mutation.py', Path('checks/r2-strict-doctor-mutation.py'))
retain(proof / 'r3-mutations.py', Path('checks/r3-mutations.py'))
retain(proof / 'r3-rebased-hold-mutation.py', Path('checks/r3-rebased-hold-mutation.py'))
for path in (proof / 'r3-rebased-mutations').iterdir():
    if path.is_file() and path.suffix in ('.json', '.log'):
        retain(path, Path('checks/r3-rebased-mutations') / path.name)
for path in (proof / 'r3-mutations').iterdir():
    if path.is_file() and path.suffix in ('.json', '.log'):
        retain(path, Path('checks/r3-mutations') / path.name)
for number in range(1, 11):
    run = proof / f'run-{number}'
    if not run.exists():
        continue
    for path in run.iterdir():
        if path.is_file() and path.suffix in ('.json', '.log'):
            retain(path, Path(f'run-{number}') / path.name)
    if number == 10:
        for path in (run / 'native').iterdir():
            if path.is_file() and path.suffix in ('.json', '.jsonl', '.log'):
                retain(path, Path('run-10/native') / path.name)

(stage / 'enforcing-artifact.patch').write_text(binding['enforcingDiff'] + '\n')
mutations = json.loads((proof / 'r3-rebased-mutations/results.json').read_text())
assert len(mutations) == 28 and all(row['killed'] for row in mutations)
for row in mutations:
    assert hashlib.sha256((repo / row['source']).read_bytes()).hexdigest() == row['originalSha256'], row['code']

manifest = {
    'issue': 'VUH-2888',
    'testedPreparationCommit': continuity['prep'],
    'enforcingProofCommit': continuity['enforcing'],
    'baselineCommit': continuity['old'],
    'finalRun': 'run-10',
    'preparationIsReachableCommittedSource': True,
    'mutationCount': 28,
    'runtime': {'platform': os.uname().sysname, 'machine': os.uname().machine},
    'claims': {'actualBaselineUpdater': True, 'fullService': True, 'realLauncherAndMcp': True,
               'nativeHarness': 'deterministic Node dependency; no provider/model',
               'allHomeAndXdgRootsScratch': True, 'originalEffects': 1, 'postUpgradeEffects': 1,
               'orphanBlocksReadiness': True},
    'limits': ['No real model or Claude provider binary was run.',
               'Owned service supervisor ports replace only the scratch service process.',
               'No production deploy, restart, broker/keychain or real seat/pane access.',
               'Uncertain hire without durable original mapping remains held.',
               'Root landing gate and standing review remain pending.'],
    'files': {str(path.relative_to(stage)): hashlib.sha256(path.read_bytes()).hexdigest()
              for path in sorted(stage.rglob('*')) if path.is_file()},
}
paths = subprocess.check_output(['git', 'diff', '--name-only', '3ae2db858', binding['sourceHead']], cwd=repo, text=True).splitlines()
source_hashes = {}
for name in paths:
    if name.startswith('docs/testing/2026-10-26-vuh-2888-seat-migration/'):
        continue
    candidate = repo / name
    snapshot = final / 'checkout' / name
    assert candidate.read_bytes() == snapshot.read_bytes(), name
    source_hashes[name] = hashlib.sha256(candidate.read_bytes()).hexdigest()
manifest['reviewedSourceMatchesPreparation'] = source_hashes
source_diff = subprocess.check_output(['git', 'diff', '--binary', binding['sourceHead'], '--', '.', ':(exclude)docs/testing/2026-10-26-vuh-2888-seat-migration/**'], cwd=repo, text=True)
assert source_diff == '', 'Candidate source changed after proof'
(stage / 'proven-to-candidate-source.diff').write_text(source_diff)
manifest['postProofChanges'] = 'Only README.md, archive.sha256 and proof.tar.gz in the VUH-2888 evidence folder; source diff is empty.'
manifest['files'] = {str(path.relative_to(stage)): hashlib.sha256(path.read_bytes()).hexdigest()
                     for path in sorted(stage.rglob('*')) if path.is_file()}
(stage / 'proof.json').write_text(json.dumps(manifest, indent=2) + '\n')
folder = repo / 'docs/testing/2026-10-26-vuh-2888-seat-migration'
folder.mkdir(parents=True, exist_ok=True)
archive = folder / 'proof.tar.gz'
with tarfile.open(archive, 'w:gz') as output:
    output.add(stage, arcname='proof')
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(folder / 'archive.sha256').write_text(f'{digest}  proof.tar.gz\n')
print(json.dumps({'archive': str(archive), 'size': archive.stat().st_size, 'sha256': digest,
                  'files': len(manifest['files']) + 1}))
