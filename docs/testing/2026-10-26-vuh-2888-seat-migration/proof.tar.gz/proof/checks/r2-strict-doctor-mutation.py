import hashlib, json, os, re, subprocess
from pathlib import Path
root = Path(__file__).resolve().parents[2]
out = root / '.local/vuh2888-proof/r2-mutations'
path = root / 'apps/tui/src/command/doctor.ts'
original = path.read_bytes()
before = 'binding.mode === "enforce"'
assert original.decode().count(before) == 1
args = ['node_modules/.bin/vitest', 'run', 'apps/tui/test/doctor-fleet-link.integration.test.ts']
try:
    path.write_text(original.decode().replace(before, 'true'))
    result = subprocess.run(args, cwd=root, env=os.environ.copy(), capture_output=True, text=True, timeout=120)
    log = result.stdout + result.stderr
    old = out / 'D1.log'
    (out / 'D1-before-strict-mode.log').write_bytes(old.read_bytes())
    old.write_text(log)
    summary = re.search(r'^\s*Tests\s+(.+)', log, re.M)
    assert result.returncode != 0 and re.search(r'^\s*Tests\s+\d+ failed', log, re.M)
    rows = json.loads((out / 'results.json').read_text())
    row = dict(code='D1', name='D1 observe/unknown diagnostics take headline', source=str(path.relative_to(root)),
               before=before, after='true', command=args, exit=result.returncode, tests=summary.group(1),
               killed=True, originalSha256=hashlib.sha256(original).hexdigest())
    rows = [row if item['code'] == 'D1' else item for item in rows]
    (out / 'results.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(json.dumps(row))
finally:
    path.write_bytes(original)
    assert path.read_bytes() == original
